package lab_6;

public abstract class Candy {
	final public static String M_N_M = "m&m";
	final public static String BOUNTY = "bounty";
	final public static String ALBENI = "albeni";
}
